use ORD_Iwashyna_201108021D
go

--Look for Flu, Legionella, C Diff lab tests
--Give Excel file to Jack to pick out tests to keep
--Added RSV, and General Viral Panel
drop table #TestNames
select labchemtestname, labchemtestsid
into #TestNames
from cdwwork.dim.labchemtest
where labchemtestname like '%flu%' or
labchemtestname like '%legion%' or
--removing mrsa labchemtestname like '%mrsa%' or 
labchemtestname like '%diff%' or
labchemtestname like '%rsv%' or
labchemtestname like '%syncytial%' or
labchemtestname like '%viral%' 
--removing mrsa labchemtestname like '%Methicillin%'

--5/17/16--Version 2, add in strep, nocardia, malaria, antigens, Pneumocystis 
drop table #TestNames2
select labchemtestname, labchemtestsid
into #TestNames2
from cdwwork.dim.labchemtest
where labchemtestname like '%strep%' or
labchemtestname like '%nocardia%' or
labchemtestname like '%malaria%' or
labchemtestname like '%antigens%' or
labchemtestname like '%pneumocystis%' 

--select distinct labchemtestname from #TestNAmes2
--order by LabChemTestName

---found some tests we missed
select labchemtestname, labchemtestsid
into #TestNames3
from cdwwork.dim.labchemtest
where labchemtestname like '%cryptococc%' or
labchemtestname like '%histoplasm%' 

--select distinct labchemtestname from #TestNAmes3
--order by LabChemTestName

--put the three tables together
select * 
into #TestNamesFinal
from #TestNAmes

union select * from #TestNames2
union select * from #TestNAmes3

--Import CSV file from jack, (lab_chem_tests_round2.csv) where he marked which tests to keep, then merge in labchemtestsid.
--5/27/16--new file imported with additional changes and tests
--then merge with labchem data
drop table #TestsKeep
select a.*,b.[Final Keep]
into #TestsKeep
from #TestNamesFinal a
left join dflt.[lab_chem_tests_round2] b
on a.labchemtestname=b.labchemtestname
where [final keep]=1 

--select distinct labchemtestname from #TestsKeep
--order by LabChemTestName

drop table dflt.lab_chem_keep

select a.labchemtestname,b.*
into dflt.lab_chem_keep
from #TestsKeep a
left join 
src.Chem_PatientLabChem b
on a.labchemtestsid=b.labchemtestsid
where b.LabChemspecimendatetime>='20050101' and b.LabChemspecimendatetime<'20150101'

--Looks at topography data and decide which to keep
--This is done by type of test, because it varies depending on the test

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%flu%' or 
labchemtestname like '%rsv%' or
labchemtestname like '%syncytial%' or
labchemtestname like '%viral%' 
group by topography
order by topography

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%diff%'
group by topography
order by topography

select distinct labchemtestname,b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%legion%' 
group by labchemtestname,topography
order by labchemtestname,topography

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%strep%'
or labchemtestname like '%histoplasm%'
group by topography
order by topography

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%malaria%' 
group by topography
order by topography

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%pneumocystis%' 
group by topography
order by topography

select distinct b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%cryptococc%' 
group by topography
order by topography

select distinct labchemtestname,b.topography,count(*) as count
from dflt.lab_chem_keep a 
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid
where labchemtestname like '%nocardia%' 
group by labchemtestname,topography
order by labchemtestname,topography

--select * from dflt.[lab chem topography]

--Import file lab chem topography.csv to determine which to keep based on test types and topography
--I created a nickname for the each type of tests to use to merge on
--This data is in the table [lab chem topography]

--Add Nickname field to Lab data, so I can merge with the topography table above
drop table #LabChem2

select a.*,b.topography,
case when labchemtestname like '%cryptococc%' then 'cryptococc'
when labchemtestname like '%pneumocystis%' then 'pneumocystis'
when labchemtestname like '%malaria%' then 'malaria'
when labchemtestname like '%strep%' or labchemtestname like '%histoplasm%' then 'strep or histoplasm'
when labchemtestname like '%legion%' and (labchemtestname like '%antigen%' or labchemtestname like '%ag%')
 then 'Legion ag'
when labchemtestname like '%legion%' and labchemtestname not like '%antigen%' and labchemtestname not like '%ag%'
 then 'Legion other'
when labchemtestname like '%diff%' then 'diff'
when labchemtestname  like '%flu%' or labchemtestname like '%rsv%' or labchemtestname like '%syncytial%' or
labchemtestname like '%viral%' then 'Viral' else null end as nickname
into #LabChem2 
from dflt.lab_chem_keep a
left join cdwwork.dim.topography b
on a.topographysid=b.topographysid

--select top 1000 * from #LabChem2
--select distinct labchemtestname from #LabChem2 where nickname is null
drop table dflt.LabChemFinal

select a.*,b.keep
into dflt.LabChemFinal
from dflt.[lab chem topography] b
left join #LabChem2 a
on a.nickname=b.test and a.topography=b.topography
where b.keep=1

--check first to be sure this works right, then go back and add where keep=1 to above statement
--select distinct LabChemTestName,Topography 
--from #LabChem3 
--where keep is null or keep=0
--order by LabChemTestName,Topography 


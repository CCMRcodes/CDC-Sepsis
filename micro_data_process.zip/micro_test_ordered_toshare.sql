use ord_iwashyna_201108021D
go

--NOTE: I started by looking up test names of interest and then the PI went through and chose which to keep or drop.
--This csv file (Ordered test_TJI.csv) was uploaded into our Research database in CDW into the dflt.ordered test_TJI table.

--ORD_Iwashyna_201108021D.dflt.Ordered tests_Tji  is a list of labchem test names to include from Jack 
select a.*,b.labchemtestsid
into #KeepList
from ORD_Iwashyna_201108021D.dflt.[Ordered tests_Tji] a
left join cdwwork.dim.labchemtest b
on a.labchemtestname=b.labchemtestname

select * from #Keeplist

--Another PI looked at the list of Workload codes and determined which to keep
--This csv file (workload_codes.csv) was uploaded into the table dflt.workload_types

--dflt.workload_types is the list from Hallie indicating which workload type/lab procedure to keep
--merge in workload code as well as lab chem testname

drop table #Keep2
select a.keep,a.flu,a.labchemtestname,b.*, c.topography,d.collectionsample,e.labprocedure,e.interest_cx
into #Keep2
from #KeepList a 
join ORD_Iwashyna_201108021D.Src.Micro_MicroOrderedTest b
on a.labchemtestsid=b.OrderedLabChemTestSID
left join cdwwork.dim.topography c
on b.topographysid=c.topographysid
left join cdwwork.dim.collectionsample d
on b.collectionsamplesid=d.collectionsamplesid
left join ORD_Iwashyna_201108021D.dflt.workload_types e
on e.workloadcode=b.OrderedTest

--The two lists above had some contradictions so we have to recitify those
--query below is where jack and hallie's lists don't match
--give this to jack to determine which combinations to exclude

select  labchemtestname,labprocedure,keep,interest_cx,count(*) as count
from #keep2
group by labchemtestname,labprocedure,keep,interest_cx

--The arbitrated list (name vs ordered test_tji.csv) was uploaded to the table dflt.name vs ordered test

--upload  list where Jack arbitrated the above list and merge in to drop unwanted combos
drop table #Keep3
select a.*,b.[arbitrated keep]
into #Keep3 
from #Keep2 a
left join dflt.[name vs ordered test] b
on a.labchemtestname=b.labchemtestname and a.labprocedure=b.labprocedure
where b.[arbitrated keep] =1 or b.[arbitrated keep] is null

--select  * from #keep3 where labchemtestname like '%missing%'

--keep only the original lab test names of interest from jack's list
--those where keep=1 and in time frame.
select * 
into #Keep4
from #Keep3
where (keep=1 or [arbitrated keep]=1) and SpecimentakenDateTime>='20050101' and SpecimenTakenDateTime<'20150101' 
--5,177,217

--look at records with missing topography or collection sample
select labchemtestname,labprocedure,topography,collectionsample, count(*) as count
from #keep4
where topography='*Missing*' or topography is null or collectionsample ='*Missing*' or collectionsample is null
group by labchemtestname,labprocedure,topography,collectionsample
order by labchemtestname,labprocedure,topography,collectionsample

--Create list of topography and collection samples for these labs and send to Jack
select topography, collectionsample,count(*)  as count
from #Keep4
group by topography, collectionsample
order by topography, collectionsample

--List of specimen types to keep or drop (specimen_Types_tji.csv) was uploaded from into dflt.specimen_types_tji
--Import list that Jack marked as keep or not keep and merge with keep4 table

select a.*,b.[Keep Non Flu],b.[Keep Flu]
into #keep5 
from #Keep4 a
left join dflt.specimen_types_tji b
on a.topography=b.topography and a.collectionsample=b.collectionsample
where (Flu=0 and [Keep Non FLu]=1) or (Flu=1 and [Keep Flu]=1)
--4,884,782

drop table ORD_Iwashyna_201108021D.Dflt.OrderedCultures

select a.sta3n,a.cohortname,a.patientsid,a.labchemtestname,a.labprocedure,a.topography,a.collectionsample,
a.specimentakendatetime--,b.patientssn
into ORD_Iwashyna_201108021D.Dflt.OrderedCultures
from #keep5 a 

select year(SpecimenTakenDateTime),count(*) as count
from ORD_Iwashyna_201108021D.Dflt.OrderedCultures
group by year(SpecimenTakenDateTime)

select max(SpecimenTakenDateTime), min(SpecimenTakenDateTime) 
from ORD_Iwashyna_201108021D.Dflt.OrderedCultures

select distinct labchemtestname,topography,collectionsample, count(*) as count
from ORD_Iwashyna_201108021D.Dflt.OrderedCulturesFinal
--where labchemtestname like '%nocardia%'
group by labchemtestname,topography,collectionsample
order by labchemtestname,topography,collectionsample

--20,469
--6/14/16 when we added in nocardia, we ended up with topographies that we didn't want
--keep only blood and bronchial stuff, drop all collection samples below.
select * 
into dflt.OrderedCulturesFinal
from dflt.OrderedCultures
where not (labchemtestname like '%nocardia%' and collectionsample in ('ABSCESS','ASPIRATE','BIOPSY','Choose:','CSF',
'FLUID','FLUID, PLEURAL','FLUID, SYNOVIAL','INDUCED SPUTUM','LESION','LUNG','LUNG ASPIRATE','LUNG TISSUE',
'PERITONEAL FLUID','PLEURAL FLUID','POST BRONCH SPUTUM','SPUTUM','SPUTUM, NOT SPECIFIED','SPUTUM,EXPECTOR',
'SPUTUM,RESP.THERAPY ASSISTED','SPUTUM,TRACH/ET','STOOL','SWAB','SYNOVIAL FLUID','TISSUE','TRACHEAL ASPIRATE','WOUND'))

